<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Mésopotamie – Irak actuel</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/Mesopotamie_Irak_actuel.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="stylesheet" type="text/css" href="css/commentaire.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
    $( function() {
      $( "#tabs" ).tabs();
    } );
    </script>
  
</head>
<body>
	<!--header-->
	<?php include("header.php"); ?>

	<!-- MAIN -->
	<main>
	<section>
		<div class="container">
			<h1 class="titre text-center">Mésopotamie – Irak actuel</h1>
			<div class="row content">
				<div class="breadcrumb_irak col-lg-12">
					<ol class="breadcrumb text-white breadcrumb_irak_titre">
					  <li class="breadcrumb-item breadcrumb_irak_titre">Mésoamérique</li>
					  <li class="breadcrumb-item breadcrumb_irak_titre">Irak actuel</li>
					</ol>
				</div>
				<div class="col-lg-7 bloc_1">
					<h2> <u>Histographie</u></h2>
					<p>
						Sumer est une région située à l'extrême sud de la Mésopotamie antique (actuel Irak), couvrant une vaste plaine parcourue par les fleuves Tigre et Euphrate, bordée, au sud-est, par le golfe Persique. Il s'y est développé une importante civilisation à compter de la fin du IVe millénaire av. J.C. et durant le IIIe millénaire av. J.C. On distingue plusieurs phases majeures dans l'histoire de la Mésopotamie du Sud : la période d'Uruk finale (v. 3400 - 3100 av. J.-C.), la période des dynasties archaïques (v. 2900 - 2340 av. J.-C.), l'empire d'Akkad (v. 2340 - 2190 av. J.-C.) et la troisième dynastie d'Ur (v. 2112 - 2004 av. J.-C.). Pour ces périodes, les synthèses récentes sur Sumer couvrent toute l'histoire de la Basse Mésopotamie, sans s'arrêter au pays sumérien précisément.
					</p>
					<p>
						Complètement oubliée après les débuts de notre ère, la civilisation de Sumer est redécouverte durant la seconde moitié du xixe siècle grâce aux fouilles de sites archéologiques du Sud mésopotamien. Celles-ci se sont poursuivies avant d'être arrêtées en raison des guerres qui affectent l'Irak à partir des années 1990. Les fouilles ont permit de découvrir des œuvres artistiques et architecturales remarquables, et ont mis au jour des dizaines de milliers de tablettes en écriture cunéiforme, qui constituent la plus ancienne documentation écrite connue avec celle de l’Égypte antique, et font de Sumer l'une des plus anciennes civilisations historiques connues. Le système d'écriture  a été mis au point durant les derniers siècles du IVe millénaire av. J.C.
					</p>
				</div>

				<aside class="aside col-lg-5">
					<div class="aside_1 card">
						<img src="images/sumer1.jpg" alt="images aztec" class="img-fluid">
						<div class="card-body">
							<p> 
								la civilisation sumérienne, née en Mésopotamie, le sud de l'actuel Irak, voici quelque 5 000 ans.
								Le miracle grec avait un précédent. Dès le troisième millénaire avant Jésus-Christ, les Sumériens avaient inventé l'écriture, fondé les premières Cités-Etats, formulé les premiers codes (le lois, donné leur première expression littéraire a . Pour une fois, les linguistes, infatigables, avaient précédé les archéologues et suggéré les fouilles qui devaient, avec la transcription des briques gravées de caractères cunéiformes, révéler au XXe siècle, stupéfait, que l'Histoire commence à Sumer. 
							</p>
						</div>
					</div>
				</aside>
			</div>
		</div>


		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class=" col-lg-12">
					<h2> <u>La langues</u></h2>
					<p>
						La langue : Le sumérien n'appartient à aucune famille de langues connue. Les locuteurs de cette langue, majoritairement localisés dans le pays de Sumer, ont été appelés « Sumériens » par les chercheurs qui l'ont découverte, mais il ne semble pas qu'une dénomination équivalente ait existé dans l'Antiquité.
					</p>
					
					<p>
						Si le souvenir des Assyriens et des Babyloniens avait été préservé grâce aux textes bibliques et grecs antiques, les Sumériens avaient été depuis longtemps effacés de l'histoire quand les premières fouilles de sites de la Mésopotamie antique débutèrent durant la première moitié du xixe siècle. Celles-ci portaient sur des sites archéologiques présentant avant tout des niveaux du iermillénaire, et de surcroit situés en Assyrie (Antiquité)Puissant empire mésopotamien de l’Antiquité, voir Syrie
						), donc en dehors de l'ancien pays de Sumer. Ce ne fut que quelques décennies plus tard que les archéologues concentrèrent leur effort vers les sites du Sud, pour y déceler les débuts de la civilisation mésopotamienne 
					</p>
					<div class="text-justify">
					<p>
						La volonté de découvrir les lieux originaires de cette civilisation habitait nombre de chercheurs à cette période, et le déchiffrement des tablettes assyriennes avait déjà incité certains à émettre des hypothèses sur l'existence d'un peuple plus ancien que ceux connus alors. Les textes cunéiformes comportaient en effet, aux côtés des signes phonétiques akkadiens (langue appartenant au groupe sémitique donc assez aisée à comprendre pour ces érudits, des signes dits « idéographiques », dont la transcription phonétique révélait une langue qui n'avait rien de connu. Les premiers déchiffreurs cherchèrent sans succès à la rattacher à une langue précise, et tâtonnèrent avant de lui trouver un nom : Henry Rawlinson et Edward Hincks penchèrent d'abord pour « akkadien », Akkad n'étant pas encore identifié comme un pays sémitique, avant que Jules Oppert ne mette en évidence le fait qu'il fallait plutôt la rattacher au terme akkadien Šumerum. Il désigna donc cette langue comme étant du « sumérien », et les recherches suivantes lui donnèrent raison. Encore fallut-il admettre qu'il s'agissait bien d'une langue qui avait été parlée : certains, comme Joseph Halévy, proposèrent au contraire que c'était une langue construite n'ayant jamais été employée ailleurs que dans le monde fermé des prêtres assyriens. Il s'agissait pourtant bien d'une langue qui avait eu de nombreux locuteurs, ces idéogrammes étant des termes sumériens conservés dans les textes en akkadien pour en faciliter l'écriture, vestiges des plus anciens temps de l'écriture, quand le sumérien était dominant1,2,3.
					</p>
				</div>

				<div class="text-justify ">
					<p>
						Les partisans de la théorie selon laquelle il s'agissait bien d'une ancienne langue eurent finalement gain de cause vers 1900. Avec la mise au jour du site de Tello, l'antique cité sumérienne de Girsu, une moisson de textes écrits uniquement en sumérien devinrent accessibles aux chercheurs. Il incomba à François Thureau-Dangind'en publier les premières traductions (notamment dans ses Inscriptions de Sumer et d’Akkad, 1905), marquant ainsi une étape décisive dans la compréhension du sumérien3. Celle-ci progressa ensuite grâce à la rédaction des premières grammaires visant à décrire cette langue, par Friedrich Delitzsch en 1914 puis Arno Poebel en 1923.
					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class="societe col-lg-12">
					<h2> <u>Une société</u></h2>
					<p>
						L'analyse de cette documentation a montré que les Sumériens ont eu une grande influence sur les civilisations antiques qui suivirent la leur, en particulier celles de la Mésopotamie. Même s'ils n'en ont pas été les seuls protagonistes, les Sumériens ont joué un rôle fondamental dans la mise en place de la civilisation mésopotamienne. Ils ont en particulier contribué à l'apparition des premiers États avec leurs institutions et administrations complexes, au développement des premières sociétés urbaines ainsi qu'à la mise au point de différentes techniques dans les domaines de l'agriculture, de la construction, de la métallurgie et des échanges commerciaux. Enfin, ils ont participé à la mise en place de systèmes de numération qui ont influencé les cultures postérieures.
					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class="pays col-lg-12">
					<h2> <u>Un pays</u></h2>
					<p class="text-justify">
						Le pays de Sumer était, durant le IIIe millénaire, une région d'environ 30 000 km2 située au sud du delta mésopotamien formé par le Tigre et l'Euphrate. Sa limite septentrionale était située autour de la cité de Nippur, à la charnière entre les pays de Sumer et d'Akkad. Au sud, sa limite est le golfe Persique, qui remontait alors bien plus au nord que de nos jours19, à peu près sur une ligne allant d'Eridu jusqu'au sud du territoire de Lagash. À l'ouest s'étend le vaste désert syro-arabe, au nord la Haute Mésopotamie, et à l'est s'élèvent les premiers contreforts des montagnes iraniennes, dans le pays qui était alors connu sous le nom d'Élam, désigné comme la contrée « élevée » (nim) dans les textes sumériens archaïques. Sumer était dominé par plusieurs cités importantes : Ur, Uruk, Eridu, Girsu, Lagash, Shuruppak, Adab, Umma, Zabalam, Nippur. Il s'agit d'un territoire dont le climat était comme de nos jours de type aride, au relief extrêmement plat. Les cours d'eau constituaient les principaux marqueurs topographiques naturels. Les espaces humides et marécageux, très nombreux notamment dans les régions littorales, étaient un autre des éléments essentiels de l'environnement des villes sumériennes, contrastant avec les marges désertiques.
					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class="peuble col-lg-12">
					<h2> <u>Un peuple</u></h2>
					<p class="text-justify">
						Dessin d'un « Sumérien » d'après les conceptions racialesdu début du XXe siècle, par E. Wallcousins pour l'ouvrage Myths of Babylonia and Assyria de D. MacKenzie (1915).
					</p>
					<p class="text-justify">
						La nature du peuple sumérien est très discutée. Les historiens de la fin du XIXe siècle et de la première moitié du XXe siècle, marqués par les problématiques raciales qui avaient cours à l'époque, cherchèrent à identifier les caractères d'une « race sumérienne », en se basant sur l'analyse des représentations des Sumériens dans l'art : selon leurs conclusions, les Sumériens auraient eu l'habitude de raser leurs cheveux et leur barbe, à la différence des Sémites chevelus et barbus. Les méthodes de l'anthropologie physique furent mobilisées pour chercher à distinguer les formes des crânes des Sumériens et de leurs voisins Sémites. Ces recherches furent vaines, comme Thorkild Jacobsen le signala judicieusement dans un article déterminant en 1939 : les anciens habitants du Sud mésopotamien ne se voyaient pas sous le prisme racial ou ethnique.
					</p>
					<img src="images/sumer8.jpg" alt="images sumer" class="sumer8 img-fluid float-right">
					<p class="text-justify">
						Depuis l'abandon de ces recherches de type racial, le terme « Sumériens » désigne des gens qui parlaient le sumérien dans leur vie courante, et sans doute guère plus. Il reste cependant assez difficile de savoir si le fait que le sumérien était la langue majoritairement écrite dans une ville à une certaine période entraine par voie de conséquence que les gens utilisaient cette langue dans la vie courante. Un autre moyen d'identifier les locuteurs du sumérien est d'étudier leurs noms, car les gens du Sud mésopotamien du IIIemillénaire avaient en majorité un nom en sumérien ou un nom en akkadien. Les études montrent bien que le pays de Sumer était celui où les textes écrits en sumérien étaient très majoritaires, de même que les gens ayant un nom en sumérien, même s'il comprenait des éléments ayant un nom en akkadien et que des Sumériens semblaient bien présents plus au nord, dans une région où dominait une population de langue sémitique, notamment dans la région de la Diyala. L'idée de l'existence de tensions entre les deux groupes à certaines périodes est généralement rejetée par les historiens, car on ne croit pas qu'il s'agissait de deux groupes distincts mais de populations vivant en symbiose, même si certains défendent encore la thèse contraire.
					</p>
					<p class="text-justify">
						De ce fait, les études sur Sumer ne se limitent que très rarement à ce cadre strict et le débordent pour traiter également de groupes de populations ne parlant pas sumérien, préférant prendre pour cadre la civilisation du Sud mésopotamien au IIIe millénaire av. J. C.dans toute sa complexité26. Il est clair que dès les premières lueurs de l'histoire, les civilisations sont déjà le produit d'une hybridation entre plusieurs populations, et qu'il ne faut pas chercher à attribuer leurs mérites au seul « génie » d'un groupe ethnique ou linguistique en particulier.
					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container infos_supp">
			<div class="row">
				<div class="col-lg-7 col-12">
					<div id="tabs">
						<ul class="tabs_ul">
							<li><a href="#tabs-1" class='a'>Lectures</a></li>
							<li><a href="#tabs-2" class='a'>Films & Documentaires</a></li>
							<li><a href="#tabs-3" class='a'>Achats divers</a></li>
							<li><button type="button" class="btn btn_images" data-toggle="modal" data-target=".modal_sumer">Images</button></li>	
						</ul>
						<div id="tabs-1">
							<ul>
								<li>Jean-Louis Huot, Les Sumériens : entre le Tigre et l'Euphrate, Paris, coll. « Néréides », 1989</li>
								<li>Paul Garelli, Jean-Marie Durand, Hatice Gonnet et Catherine Breniquet, Le Proche-Orient asiatique : Des origines aux invasions des peuples de la mer</li>
								<li>Samuel Noah Kramer (préf. Jean Bottéro), L'histoire commence à Sumer, Paris, Flammarion, coll. « Champs », 1994 (1re éd. 1957)</li>
							</ul>
						</div>
						<div id="tabs-2">
							<ul>
								<li><a href="https://www.youtube.com/watch?v=MqGSf6K4D0o&list=RDcvjcpVnjIP8&index=3 " target="blank">L'histoire des Sumériens, 1ère civilisation au monde</a></li>
								<li><a href="https://www.youtube.com/watch?v=syRf7enCk3I ">Il était une fois la Mésopotamie (Le pays entre les deux fleuves) </a></li>
							</ul>		
						</div>
						<div id="tabs-3">
							<p>
								En cliquant sur le lien ci-dessous, vous pourrez effectuer des achats (films, documentaires, livres).
							</p>
							<p>Pour les achats, c'est <a href="achat_sumer.php" alt="page redirection" target="blank">ICI</a></p>
						</div>
					</div>

					<div class="modal fade modal_sumer galerie_images" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
					  <div class="modal-dialog modal-lg">
					    <div class="modal-content">
					      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
							  <div class="carousel-inner">
							    <div class="carousel-item active">
							      <img class="d-block w-100" src="images/mesop1.jpg" alt="First slide">
							    </div>
							    <div class="carousel-item">
							      <img class="d-block w-100" src="images/mesop2.jpg" alt="Second slide">
							    </div>
							    <div class="carousel-item">
							      <img class="d-block w-100" src="images/sumer3.jpg" alt="Third slide">
							    </div>
							  </div>
							  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
							    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
							    <span class="sr-only">Previous</span>
							  </a>
							  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
							    <span class="carousel-control-next-icon" aria-hidden="true"></span>
							    <span class="sr-only">Next</span>
							  </a>
							</div>
					    </div>
					  </div>
					</div>

				</div>
				<div class="infos col-lg-5 col-12">
					<h2> A savoir : </h2>
					<ul class="text-justify">
						<li>Société hiérarchisée socialement avec des structures politiques, administratives, économiques</li>
						<li>Activités économiques : artisanat :poterie, construction, textile, métallurgie</li>
						<li>Ingéniosité : agriculture productive et élevage, grenier à céréales du Moyen Orient antique malgré le milieu naturel non favorable à la croissance des plantes : températures élevées, précipitations insuffisantes, crues au printemps (moisson). Mise en place d’un immense réseau d’irrigation. Techniques de désalinisation des eaux, rendements très élevés et constants.
						</li>
						<li>Artisanat et techniques : maitrise de divers matériaux (argile, roseaux, bois pour la construction d’habitations, bateaux , outils ; fibres végétales pour le textile, bitume pour étanchéifier objets ou murs, comme colle ; transformation des produits animaux (laine, poils, peaux, nacre) ; transformation de pierres fines (albâtre, chlorite, diorite, cornaline, agate, lapis-lazuli) pour la bijouterie, objets d’art et sculptures ; transformation de l’or, cuivre, argent, plomb, arsenic, étain.
</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

	<div class="container hr">
		<div class="row">
			<hr class="offset-lg-3 col-lg-6 offset-lg-3">
		</div>
	</div>

	<section>
		<div class="container com">
			<div class="row">
				<?php include("commentaire.php"); ?> 
			</div>
		</div>
	</section>
	</main>
	<?php
		require_once ("commentaires/connexion.php");
		$req = "SELECT * FROM commentaires";
		$ps = $pdo -> prepare ($req);
		$ps->execute();
	?>

	<?php while ($com=$ps->fetch()){?>
	<!-- commentaires : fetch = relier toutes les lignes de la table -->
	
	<?php $identifiant = $_POST['identifiant'];
	setcookie('identifiant', $_POST['identifiant'], time() + 365*24*3600, null, null, false, true); ?>
	    <h6>
	    	<i><?php echo htmlspecialchars($com['date_publication'])?></i>
	    	<?php if (isset($_COOKIE['identifiant'])){
	    		echo $_COOKIE['identifiant'];} ?>
	    </h6>
	    <p><?php echo htmlspecialchars($com['commentaire'])?></p>
	    
	<?php }?>
	<!--footer -->
	<?php include("footer.php"); ?> 
</body>
</html>                 
