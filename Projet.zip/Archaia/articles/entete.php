<!DOCTYPE html>
<html>
<head>
	<title>Entête des membres</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" type="text/css" href="css/myStyle.css"/>
</head>
<body>
	<div class="navbar navbar-inverse navbar-sticky-top">
		<ul class="nav navbar-nav">
			<li><a href="membres.php">Membres</a></li>
		</ul>
	</div>
</body>
</html>
