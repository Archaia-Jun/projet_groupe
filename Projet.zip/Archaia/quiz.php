<!DOCTYPE html>
<html>
<head>
  <title>Quiz</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
  <style type="text/css">
		body {
			background-color: #fdeac9 !important;
		}

		#contenu {
			margin-top: 150px;
			margin-bottom: 150px;
		}
	</style>
</head>
<body>

	<!--header-->
	<?php include("header.php"); ?>
	
	<div id="contenu">
	</div>

	<!--footer -->
	<?php include("footer.php"); ?> 


	<script type="text/javascript">
		// Liste des questions à afficher. Une question est définie par son énoncé et sa réponse
		var questions = [
		    {
		        enonce: "Que peuple est aussi appelé « Les gens du pays du Caoutchouc » ?",
		        reponse: "Les Olmèques",
		        indice : 'Les Incas / Les olmèques / Les Gréco-Romains / Les Aztèques'
		    },
		    {
		        enonce: "A quel peuple associe-t-on le « culte du Jaguar » ?",
		        reponse: "Les Olmèques",
		        indice : 'Les Sumériens / Les Harappéens /  Les Olmèques / Ce culte n’existe pas'
		    },
		    {
		        enonce: "Quelle civilisation était avancée en termes de connaissances sur le domaine de l’astronomie ?",
		        reponse: "Les Mayas",
		        indice : 'Les Egyptiens / Les Mayas / Les Araméens / les Assyriens'
		    },
		    {
		        enonce: "De quelle région géographique proviennent les Harappéens ?",
		        reponse: "L’Indes",
		        indice : 'La Russie / L’Inde / L’Éthiopie / Le Canada'
		    },
		    {
		        enonce: "Quelle fut la cause de l’exode des Minoens ?",
		        reponse: "Une catastrophe climatique",
		        indice : 'Une catastrophe climatique / apparition d’une épidémie / les conditions climatiques /  Conflits et guerres'
		    },
		    {
		        enonce: "Les Minoens représentent une civilisation ?",
		        reponse: "Crétoise",
		        indice : 'Crétoise – Carthaginoise / Précolombienne / Amérindiennes'
		    },
		    {
		        enonce: "L’Egypte antique date de : ",
		        reponse: "-3100 av J.C. à -30 av JC",
		        indice : '-3100 av J.C. à -30 av JC /  -2000 av JC à -100 av JC / -500 av JC à 50 av JC / -1250 av J.C. à -750 av J.C'
		    },
		    {
		        enonce: 'Les Incas se servaient des « Quipus » comme: ',
		        reponse: "système de représentation des nombres",
		        indice : 'Outils pour chasse – matériaux de construction -  système de représentation des nombres – moyens de communication'
		    },
		    {
		        enonce: 'Parmi ces pays lequel ne dispose pas de Pyramides anciennes ?',
		        reponse: "Lituanie",
		        indice : 'Chine / Mexique / Italie  / Lituanie'
		    },
		    {
		        enonce: 'Comment se jouait le jeu de balle ancestral des peuples précolombiens ?',
		        reponse: " Sans les mains et les pieds",
		        indice : 'Avec les mains  / Avec les pieds / Sans les mains et les pieds / Avec une raquète'
		    }
		];

		var i = 1;
		questions.forEach(function (questions) {
	    
	    // creation des éléments
	    var span = document.createElement('span');
	    var paraEnonce = document.createElement('p');
	    var button = document.createElement('button');
	    var reponse = document.createElement('p');
	    var indice = document.createElement('button');
	    var spanIndice = document.createElement('span');
	    var inputValider= document.createElement('input');
	    var paraInput = document.createElement('p');

	    // ajout contenu et style
	    span.textContent = 'Question ' + i + ' : ';
	    button.textContent = "Valider";
	    paraEnonce.style.textAlign = "center"; 
	    
	    indice.textContent = "Indice";
	    indice.style.marginLeft = "10px";

	    inputValider.style.marginRight = "10px";
	    inputValider.style.textAlign = "center";
	    inputValider.type = "text";
	    inputValider.setAttribute("value", "");

	    paraInput.style.textAlign = "center";
	    reponse.style.textAlign = "center";

	    // insertion dans le DOM
	    paraEnonce.appendChild(span);
	    paraEnonce.appendChild(document.createTextNode(questions.enonce));
	    paraEnonce.appendChild(spanIndice);
	    paraEnonce.appendChild(indice);
	    document.getElementById('contenu').appendChild(paraEnonce);
	    paraInput.appendChild(inputValider);
	    paraInput.appendChild(button);
	    document.getElementById('contenu').appendChild(paraInput);
	    document.getElementById('contenu').appendChild(reponse);
	    
	    
	 
	   	// au click du bouton VALIDER
	    button.addEventListener('click', function() {
	    	var a = questions.reponse.toUpperCase();;
	    	var b = inputValider.value.toUpperCase();

	        if (a === b) {
	        	button.style.display = "none";
	        	inputValider.style.display = "none";
	            reponse.innerHTML = "Bonne reponse";
	            reponse.style.color = "green";

	        }
	        else {
	        	button.style.display = "none";
	        	inputValider.style.display = "none";
	            reponse.innerHTML = "Mauvaise reponse. La réponse est : " + questions.reponse;
	            reponse.style.color = "red";
	        }
	    });

	    // au click du boutton
	    indice.addEventListener('click', function() { 
	    	indice.style.display = "none"
	    	spanIndice.innerHTML = questions.indice 
	    	spanIndice.style.marginLeft = "10px";
	    	spanIndice.style.fontWeight = "bold"
	    });

     i++;
});
	</script>
</body>
</html>