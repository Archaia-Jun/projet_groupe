<!-- Footer -->
<footer class="py-5">
	<div class="container">
	  	<div class="reseaux text-center">
	   		<img src="images/facebook.png">
	   		<img src="images/twitter.png">
	   	</div>
	   	<p class="m-0 text-center text-white">Copyright &copy; Your Website 2018</p>
 	</div>
<!-- /.container -->
</footer>
