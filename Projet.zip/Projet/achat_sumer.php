<!DOCTYPE html>
<html>
<head>
  <title>Archaia - Achat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="stylesheet" type="text/css" href="css/achat_sumer.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
</head>
<body>

	<!--header-->
	<?php include("header.php"); ?>

	<main>
		<section>
			<div class="container ">
				<div class="row">
					<div class="header_jum col-lg-12">
						<div class="jumbotron_achat jumbotron">
						    <h1 class="display-4">Achat</h1>
						    <p class="lead">Nous mettons à votre disposition une selection d'article (films, documentaires et séries), et des liens redirigeant vers des sites commerçants.</p>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section>
			<div class="container">
				<div class="row">
					<div class="accordion col-12" id="accordion">
					  <div class="card">
					    <div class="card-header" id="headingOne">
					      <h5 class="mb-0">
					        <button class="btn btn-link btn_achat" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
					          Mésoamérique – Amérique précolombienne / Lectures
					        </button>
					      </h5>
					    </div>
					    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
					      <div class="card-body">
					        <div class="row achat_deck">
					        	<div class="col-12 col-sm-4">
									<div class="achat_olmeques card border-success mb-3">
										<div class="card-body text-success">
											<img src="images/mesopotamie.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success"><a href="https://www.amazon.fr/gp/product/2251410171?ie=UTF8&tag=babelio-21&linkCode=as2&camp=1642&creative=6746&creativeASIN=2251410171" target="blank" class="lien_olmeque"> 19 euros</a></div>
									</div>
								</div>
								<div class="col-12 col-sm-4">
									<div class="achat_olmeques card border-success mb-3">
										<div class="card-body text-success">
											<img src="images/sumer_invention.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success"><a href="https://www.amazon.fr/Ecrire-%C3%A0-Sumer-linvention-cun%C3%A9iforme/dp/2020385066/ref=sr_1_8?s=dvd&ie=UTF8&qid=1524759082&sr=8-8&keywords=livres+civilisation+sumer" target="blank" class="lien_olmeque">29,40 euros </a></div>
									</div>
								</div>
								<div class="achat_olmeques col-12 col-sm-4">
									<div class="achat_olmeques card border-success mb-3">
										<div class="card-body text-success">
											<img src="images/sumer_civilisation.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success"><a href="https://www.amazon.fr/dp/B00HDDSAS6/ref=rdr_kindle_ext_tmb" target="blank" class="lien_olmeque"> 9,99 euros </a></div>
									</div>
								</div>
								<p><a href="https://www.amazon.fr/s/ref=nb_sb_noss?__mk_fr_FR=%C3%85M%C3%85%C5%BD%C3%95%C3%91&url=search-alias%3Dstripbooks&field-keywords=civilisation+mesopotamie&rh=n%3A301061%2Ck%3Acivilisation+mesopotamie" target="blank" class="lien_olmeque">En cliquant sur ce lien vous aurez plus de choix</a></p>
						      </div>
						    </div>
						</div>


					  <!--<div class="card">
					    <div class="card-header" id="headingTwo">
					      <h5 class="mb-0">
					        <button class="btn btn-link collapsed btn_achat" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
					          Mésoamérique – Amérique précolombienne / Films & Documentaires
					        </button>
					      </h5>
					    </div>
					    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
					      <div class="card-body">
					      	<div class="row achat_deck">
					        	<div class="col-12 col-sm-4">
									<div class="achat_olmeques card border-success mb-3">
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class=" achat_olmeques card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-12 col-sm-4">
									<div class="achat_olmeques card border-success mb-3">
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-12 col-sm-4">
									<div class="achat_olmeques card border-success mb-3">
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<p><a href="#">En cliquant sur ce lien vous aurez plus de choix</a></p>
						      </div>
						    </div>
						</div>-->
					  </div>
					</div>
				</div>
			</div>
		</section>
	</main>

	<!--footer -->
	<?php include("footer.php"); ?> 
</body>
</html>