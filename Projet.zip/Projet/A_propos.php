<!DOCTYPE html>
<html>
<head>
  <title>Vallée de I'Indus </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/A_propos.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">

  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
    $( function() {
      $( "#tabs" ).tabs();
    } );
    </script>
  
</head>
<body>
    <!--header-->
    <?php include("header.php"); ?>

    <!-- MAIN -->
    <main class="top">
    <section>
        <div class="container">
            <h1>Contexte:</h1>
            <div class="row">
                <div class="a_propos col-12">
                    
                    <p class="text-justify">Le thème des civilisations suscite l’intérêt et la curiosité (cf Google Trend, qui permet de connaître la fréquence à laquelle un terme a été tapé dans le moteur de recherche Google), En effet, les cinq continents sont concernés, avec certaines civilisations très connues et d’autres moins.
                    Ce site spécialisé a pour objectif de permettre à chacun d’accroitre sa culture générale, d’échanger avec d’autres visiteurs du site et d’apporter des informations complémentaires pouvant enrichir la base de données.
                    Il permettra également d’avoir accès à des éléments en lien avec le thème et différents sujets s’y rapportant, par exemple des ouvrages, des travaux de chercheurs (Historiens, Géographe, Anthropologue), documentaires.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
      <div class="container">
        <div class="row">
          <h2 class="sources col-lg-12">Les sources utilisées :</h2>
          <div class="text col-lg-12 text-justify"> 
              <h3>Pour le texte : </h3>
              <p>Wikipedia, Wikistrike, Wikimedia, Wikitionary,
                  Olmèques :www.clio.fr.
              </p>
          </div>

          <div class="images col-lg-12 text-justify"> 
              <h3>Pour les images : </h3>
              <p>
                Sumer :Table de division et de conversion des fractions, écriture cunéiforme• Crédits : Creative Commons
              </p>
              <p>https://www.franceculture.fr/emissions/la-methode-scientifique/quand-lhumanite-t-elle-appris-compter.</p>

              <p><span>Site Archéologique Mexique<span> : www.istockphoto.co et www.bigstockphoto.com.</p>
          </div>

          <div class="video col-lg-12 text-justify"> 
              <h3>Vidéos</h3>
              <p> Youtube </p>
          </div>
          
           <div class="internet col-lg-12 text-justify"> 
              <h3>Sites internet</h3>
              <p> Sites internet : Amazon, Fnac, Ebay, www.harappa.com, www.babelio.com, www.edelo.net, www.courrierinternational.com, www.sciences-faits-histoires.com, www.atlantico.fr, www.cultura.com, www.letemps.ch, data.bnf.fr, gallica.bnf.fr, www.histoire-du-monde.fr, www.la-nrh.fr, www.franceculture.fr, www.qualitativelife.com, slideplayer.fr, avenoel.org. </p> 

          </div>
      </div>
    </section>
    </main>

    <!--footer -->
    <?php include("footer.php"); ?> 
</body>
</html>                 
