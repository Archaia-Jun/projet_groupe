<!DOCTYPE html>
<html>
<head>
  <title>Archaia - Mésoamérique – Amérique précolombienne</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/Mesoamerique_Amerique_precolombienne.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="stylesheet" type="text/css" href="css/commentaire.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
    $( function() {
      $( "#tabs" ).tabs();
    } );
    </script>
  
</head>
<body>
	<!--header-->
	<?php include("header.php"); ?>

	<!-- MAIN -->
	<main>
	<section>
		<div class="container text-center">
			<h1 class="titre">Mésoamérique – Amérique précolombienne </h1>
			<div class="row content">
				<div class="breadcrumb_Olmeques col-lg-12">
					<ol class="breadcrumb text-white breadcrumb_Olmeques_titre">
					  <li class="breadcrumb-item breadcrumb_Olmeques_titre">Mésoamérique</li>
					  <li class="breadcrumb-item breadcrumb_Olmeques_titre">Olmèques</li>
					</ol>
				</div>
				<div class="col-lg-7 bloc_1">
					<h2> <u>Historiographie </u></h2>
					<img src="images/Olmeques_histographie.jpg" alt="Olmèques_histographie" class="img-fluid Olmeques_histographie">
					<p>
						Ils représentent la source culturelle principale des civilisations d’Amérique centrale. La proéminence de cette racine culturelle a été discutée par certains auteurs, dans l’attente de nouvelles découvertes futures permettant d’apporter des précisions et de clore les débats. Cette question fut tranchée en 1955 grâce à la datation par le carbone 14.
					</p>
					<p>
						Première véritable civilisation Méso-Américaine dont nous ayons trace à ce jour, l’impact fondamental des Olmèques sur les civilisations qui les ont succédés est admise et reconnue par les Historiens et Archéologues, équivalent à l’influence de la Grèce Antique sur le monde Latin et Occidental ; ils sont considérés comme la racine des cultures précisées plus haut.
					</p>
					<p>
						<u>Dates</u> : 1200 avant J-C à 500 avant J-C  sur la côte du golfe du Mexique, bassin de Mexico, le long de la côte Pacifique.
					</p>
					<p>
						Pourquoi on en parle très peu : Leur redécouverte est récente, La culture Olmèque demeure inconnue jusqu’à la seconde moitié du XIXe siècle. Egalement, leur période est antérieure à la période des Conquistadores ; à l’arrivée des Espagnols en Amérique Centrale il ne restait que des ruines de cette civilisation, l’archéologie a permit leur redécouverte.
					</p>
					<p>
						Dans l’ouvrage « Tribes and Temples » (1926), l’archéologue Frans Blom et l’ethnologue Olivier La Farge décident, en 1925, d’explorer le sud-est du Mexique à la recherche des ruines Mayas. Des ruines Olmèques furent attribuées à tort au Mayas.
					</p>
					<p>
						Dans l’ouvrage « Tribes and Temples » (1926), l’archéologue Frans Blom et l’ethnologue Olivier La Farge décident, en 1925, d’explorer le sud-est du Mexique à la recherche des ruines Mayas. Des ruines Olmèques furent attribuées à tort au Mayas.
					</p>
				</div>

				<aside class="aside col-lg-5">
					<div class="aside_1 card">
						<img src="images/aztec.jpg" alt="images aztec" class="img-fluid">
						<div class="card-body">
							<p>
								Hier encore inconnue, la civilisation des Olmèques s'impose aujourd'hui comme la source des hautes cultures précolombiennes. Plus de mille ans avant notre ère, ce peuple mystérieux a élevé pyramides et temples, sculpté des stèles et des autels, ciselé les pierres dures, inventé l'écriture hiéroglyphique. Pendant près d'un millénaire, les Olmèques ont construit leurs centres cérémoniels dans la jungle torride du Mexique oriental, et, de là, ont essaimé vers l'ouest et vers l'est, jusqu'au Pacifique, jusqu'au Salvador. <br>
								Les céramiques de Las Bocas et de Tlatilco,les panneaux sculptés et les peintures murales du Guerrero et du Morelos, les figurines de jade, les représentations énigmatiques de personnages masqués, d'hommes-jaguars et d'enfants divins, reflètent dans leur diversité un style puissant et original. Avec les Olmèques, apparaissent les thèmes fondamentaux de l'art précolombien en Méso-Amérique : ils persisteront à travers toutes les variations, des Maya aux Aztèques, pendant quinze siècles.
							</p>
						</div>
					</div>
				</aside>
			</div>
		</div>

		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p>
						Au XVIe siècle, les Aztèques employaient les mots Olman et Olmeca pour désigner la côte du Mexique et ses habitants, puis le mot fut reprit pour établir des liens entre les artefacts trouvés (matériels, ustensiles : haches, monolithes..) et à les regrouper sous le dénomination « style Olmèque » 
					</p>
				</div>
				<aside class="aside aside_1_responsive col-lg-5">
					<div class="card">
						<img src="images/aztec.jpg" alt="images aztec" class="img-fluid">
						<div class="card-body">
							<p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
							<p> <span>Lorem : </span> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
							tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
							quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
							consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
							cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
							proident.Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod.
							</p>
						</div>
					</div>
				</aside>
			</div>


		</div>
		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class="">
					<h2> <u>Les Origines </u></h2>
					<img src="images/img1.jpg" alt="img" class="img1 img-fluid float-left">
					<p>
						Aujourd’hui la culture olmèque apparaît comme un ensemble multiethnique et plurilinguistique qui s’étend de 1200 AV JC jusqu’ à 500 av JC sur une vaste partie de la Méso-Amérique. Ils ont été présents sur la Cote du Golfe dans le bassin de Mexico le long de la côte Pacifique, dans les Etas Mexicain de Guerrero, Oaxaca et Chiapas. On recense des vestiges Olmèques au Guatemala et même jusqu’au Costa Rica.
					</p>
					<p>
						On trouve des effigies et statues en terre cuite, des poteries noires incisées de motifs abstraits, et des objets revêtant la forme d’animaux. Le milieu n'était pas approprié pour leur conservation, ce qui explique que les meilleurs exemplaires de céramique proviennent surtout des hautes terres où s'est propagée la culture olmèque ainsi que son style si caractéristique. 
					</p>
					<p>
						Plus récemment, sur le site de La Venta,  monolithes, stèles, autels sacrificiels, lourdes statues confectionnées en roche magmatique (duorite) et serpentine (famille de minéraux du groupe des Sillicates) représentants des personnages ont été trouvés ainsi que des ustensiles. On a également découvert au centre de l’île des tumuli (tumulus , amas de terre en forme conique recouvrant les sépultures pour servir de tombeau), terrains de jeu de balles , des traces d’urbanisme et surtout la première pyramide Mexicaine datant de 1000 ans avant notre ère.
					</p>

					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
						Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
					</p>
				</div>

				<div class="text-justify">
					<p>
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
						tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
						quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
						consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
						cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
						proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 
					</p>
				</div>
			</div>
		</div>
			

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container infos_supp">
			<div class="row">
				<div class="col-lg-7 col-12">
					<div id="tabs">
						<ul class="tabs_ul">
							<li><a href="#tabs-1" class='a'>Lectures</a></li>
							<li><a href="#tabs-2" class='a'>Films & Documentaires</a></li>
							<li><a href="#tabs-3" class='a'>Achats divers</a></li>
							<li><button type="button" class="btn btn_images" data-toggle="modal" data-target=".modal_olmeques">Images</button></li>	
						</ul>
						<div id="tabs-1">
							<ul class="text-justify">
								<li>L'art olmèque. Source des arts classiques du Mexique, In Catalogue d'exposition, Musée Rodin, Paris, 1972</li>
								<li>Christian Duverger, La Méso-Amérique, Flammarion, 1999</li>
								<li>Caterina Magni, Les Olmèques : Des origines au mythe, Seuil</li>
								<li>Karl Taube, Olmec Art at Dumbarton Oaks, Dumbarton Oaks Research Library, 2004.</li>
								<li>Caterina Magni, Les Olmèques. La genèse de l'écriture en Méso-Amérique, Paris, Errance, 2014</li>
							</ul>
						</div>
						<div id="tabs-2">
							<ul>
								<li><a href="https://www.youtube.com/watch?v=cvjcpVnjIP8&list=RDcvjcpVnjIP8 " target="blank">Nazca</a></li>		
							</ul>	
						</div>
						<div id="tabs-3">
							<p>
								En cliquant sur le lien ci-dessous, vous pourrez effectuer des achats (films, documentaires, livres).
							</p>
							<p>Pour les achats, c'est <a href="achat_olmeques.php" alt="page redirection" target="blank">ICI</a></p>
						</div>
					</div>

					<div class="modal fade modal_olmeques galerie_images" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
					  <div class="modal-dialog modal-lg">
					    <div class="modal-content">
					      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
							  <div class="carousel-inner">
							    <div class="carousel-item active">
							      <img class="d-block w-100" src="images/img4.jpg" alt="First slide">
							    </div>
							    <div class="carousel-item">
							      <img class="d-block w-100" src="images/img3.jpg" alt="Second slide">
							    </div>
							    <div class="carousel-item">
							      <img class="d-block w-100" src="images/img6.jpg" alt="Third slide">
							    </div>
							    <div class="carousel-item">
							      <img class="d-block w-100" src="images/img1.jpg" alt="quatre slide">
							    </div>
							    <div class="carousel-item">
							      <img class="d-block w-100" src="images/olmeque6.jpg" alt="cinq slide">
							    </div>
							  </div>
							  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
							    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
							    <span class="sr-only">Previous</span>
							  </a>
							  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
							    <span class="carousel-control-next-icon" aria-hidden="true"></span>
							    <span class="sr-only">Next</span>
							  </a>
							</div>
					    </div>
					  </div>
					</div>


					
				</div>
				<div class="infos col-lg-5 col-12">
					<h2> A savoir : </h2>
					<ul class="text-justify">
						<li>période : environ -1200 jusqu’à -500 avant notre ère.</li>
						<li>Lieu : Golfe du Mexique, Mexique actuel</li>
						<li>Civilisation - mère de la Mésoamérique ayant influencée les toutes les suivantes</li>
						<li>Réputés pour l’Art, les matériaux et techniques utilisées (argile, pierre, bois, jade, serpentine, obsidienne taillage de grands blocs de pierre), sculptures peintures rupestres, art monumental et mineur, bijoux, architecture : pyramides, terrains de jeu de balle, écriture, calendrier</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

	<div class="container hr">
		<div class="row">
			<hr class="offset-lg-3 col-lg-6 offset-lg-3">
		</div>
	</div>

	<section>
		<div class="container com">
			<div class="row">
				<?php include("commentaire.php"); ?> 
			</div>
		</div>
	</section>
	</main>

	<!--footer -->
	<?php include("footer.php"); ?> 
</body>
</html>                 
