<!DOCTYPE html>
<html>
<head>
  <title>Vallée de I'Indus </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/Vallee_de_Iindus.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="stylesheet" type="text/css" href="css/commentaire.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
    $( function() {
      $( "#tabs" ).tabs();
    } );
    </script>
  
</head>
<body>
	<!--header-->
	<?php include("header.php"); ?>

	<!-- MAIN -->
	<main>
	<section>
		<div class="container">
			<h1 class="titre text-center">Vallée de l’Indus</h1>
			<div class="row content">
				<div class="breadcrumb_irak col-lg-12">
					<ol class="breadcrumb text-white breadcrumb_irak_titre">
					  <li class="breadcrumb-item breadcrumb_irak_titre">Vallée de l’Indus</li>
					  <li class="breadcrumb-item breadcrumb_irak_titre">Harapéens</li>
					</ol>
				</div>
				<div class="col-lg-7 bloc_1">
					<h2> <u>Histographie</u></h2>
					<p>
						La civilisation harappéenne (v. 8000 av. J.-C.1 – 1900 av. J.-C.), dite aussi civilisation de la vallée de l'Indus , est une civilisation de l'Antiquité dont l'aire géographique s'étendait principalement dans la vallée du fleuve Indus dans le sous-continent indien (autour du Pakistan moderne). Bien que probable, l'influence qu'elle a pu avoir sur la culture hindoue contemporaine n'est pas clairement établie.
					</p>
					<p>
						Oubliée par l’Histoire jusqu’à sa redécouverte dans les années 1920, la civilisation de l’Indus se range parmi ses contemporaines, la Mésopotamie et l’Égypte ancienne, comme l’une des toutes premières civilisations, celles-ci étant définies par l'apparition de villes, de l’agriculture, de l’écriture, etc.
					</p>
					<p>
						Si la civilisation de l’Indus n’est pas la première civilisation antique, la Mésopotamie et l’Égypte ayant développé des villes peu avant, elle est cependant celle qui connaît la plus grande extension géographique. À ce jour, sur les 1 052 sites qui ont été découverts, plus de 140 se trouvent sur les rives du cours d'eau saisonnier Ghaggar-Hakra. D’après certaines hypothèses, ce système hydrographique, autrefois permanent, arrosait la principale zone de production agricole de la civilisation de l’Indus.
					</p>
					<p>
						La plupart des autres sites se situent le long de la vallée de l’Indus et de ses affluents mais on en trouve aussi à l’ouest jusqu’à la frontière de l’Iran, à l’est jusqu’à Delhi, au sud jusque dans le Maharashtra et au nord jusqu’à l’Himalaya. Parmi ces sites, on compte de nombreuses villes comme Dholavira, Ganweriwala, Mehrgarh, Harappa, Lothal, Mohenjo-daro et Rakhigarhi. À son apogée, sa population pourrait avoir dépassé cinq millions de personnes.
					</p>
					<p>
					Malgré toutes ces réalisations, cette civilisation est très mal connue. Son existence même a été oubliée jusqu’au XXe siècle. Son écriture reste indéchiffrée et on ne sait pas si elle a un lien quelconque avec l’écriture brahmi, ce qui semble peu probable au regard des connaissances actuelles. Parmi les mystères que cette civilisation recèle, trois questions au moins sont fondamentales : 
					<ul>
						<li>formait-elle un État, ou une cité-état un système de pouvoir ?</li>
						<li>quels étaient ses moyens de subsistance ?</li>
						<li>quelles sont les causes de sa disparition soudaine et dramatique, à partir du XVIIIe siècle av. J.-C. ?</li>
					</ul>
					La langue utilisée par ses membres et le nom qu’ils se donnaient restent à ce jour indéchiffrés.
				</p>
				</div>

				<aside class="aside col-lg-5">
					<div class="aside_1 card">
						
						<img src="images/indus4.jpg" alt="images" class="img-fluid ">
						<div class="card-body">
							<p>
								Oubliée par l’Histoire jusqu’à sa redécouverte dans les années 1920, la civilisation de l’Indus se range parmi les toutes premières civilisations, au même moment que la Mésopotamie et l’Égypte ancienne. Avec une superficie de 2,5 millions de kilomètres carrés, il s'agissait à l'époque de la civilisation la plus étendue au monde : elle regroupait cinq millions de personnes, soit 10% de la population mondiale de l'époque.
								Cette civilisation, dite aussi civilisation harappéenne, qui s'étendait sur ce qui est aujourd'hui le Pakistan, l'Inde et l'Afghanistan, a subitement disparu vers 1900 av-JC, probablement victime d'un changement climatique.
								Puis a été oubliée, faute d'ouvrages monumentaux ayant traversé le temps comme les pyramides d'Egypte. On a simplement découvert, depuis les années 1920, plus d'un millier de sites : des maisons de briques séchées, des salles de bains, des puits, les premières toilettes au monde… Par contre, dans ses grandes villes divisées en quartiers, nuls temples, palais ou équipement militaire. <br>
								Un siècle après sa redécouverte fortuite par un archéologue indien qui cherchait les vestiges d’un ancien temple bouddhiste, les mystères sont encore nombreux : nul ne connait son système de pouvoir, ni ses 

							</p>
						</div>
					</div>
				</aside>
			</div>
		</div>
		
		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class=" col-lg-12">
					<h2> <u>Les prédécesseurs</u></h2>
					<p>
						La civilisation de l'Indus a été précédée par les premières cultures agricoles de l'Asie du Sud qui sont apparues dans les collines du Balouchistan, à l'ouest de la vallée de l'Indus. Le site le mieux connu de cette culture est Mehrgarh, datant des années 6500 av. J.-C.. Ces premiers fermiers maîtrisèrent le blé et domestiquèrent une grande variété d'animaux, en particulier ceux constituant le bétail. La poterie y était utilisée vers 5500 av. J.-C. La civilisation de l'Indus s'est développée à partir de cette base technologique, en se répandant dans la plaine alluviale de ce que sont, de nos jours, les provinces actuelles pakistanaises du Sind et du Pendjab.
						Autour de 4000 av. J.-C., une culture régionale originale, appelée pré-harappéenne, apparaît dans cette aire (elle porte ce nom car les sites de cette culture sont retrouvés dans les premières strates des villes de la civilisation de l'Indus). Des réseaux commerciaux la relient avec des cultures régionales parentes et avec des sources de matières premières, telles que le lapis-lazuliet autres pierres fines utilisées dans la fabrication de perles à collier. Les villageois ont domestiqué à cette époque un grand nombre d'espèces tant végétales dont les petits pois, les pois chiches, les grains de sésame, les dattes et le coton, qu'animales telles que le buffle, un animal qui reste essentiel à la production agricole dans toute l'Asie actuelle. Le cheval ne semble pas être domestiqué.
					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div>
					<h2> <u>Émergence de la civilisation</u></h2>
					<p>
						Autour de 2600 av. J.-C., quelques sites pré-harappéens se développent en cités, abritant des milliers d'habitants, essentiellement des agriculteurs. Par suite, une culture unifiée apparaît dans toute la zone, aplanissant les différences régionales de sites éloignés de plus de mille kilomètres. Cette émergence est si soudaine que certains chercheurs pensent qu'elle résultait d'une conquête extérieure ou d'une migration mais ils sont minoritaires. Depuis, les archéologues sont convaincus d'avoir fait la preuve qu'elle est issue de la culture pré-harappéenne qui l'a précédée. En fait, il semble que cette soudaineté soit le résultat d'un effort délibéré, planifié. Par exemple, quelques sites paraissent avoir été réorganisés pour se conformer à une planification réfléchie. C'est la raison pour laquelle la civilisation de l'Indus est considérée comme la première à avoir développé une planification urbaine ; sachant qu'une planification à grande échelle implique unité politique.
					</p>
				</div>
			</div>
		</div>



		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class="societe col-lg-12">
					<h2> <u>Déclin et effondrement</u></h2>
					<p>
						Durant 700 ans, la civilisation de l'Indus fut prospère et ses artisans produisirent des biens d'une qualité recherchée par ses voisins. Puis aussi soudainement qu'elle était apparue, elle entra en déclin et disparut.
					</p>
					<p>
						Vers 1900 av. J.-C., des signes montrent que des problèmes apparaissent. Les gens commencent à quitter les cités. Ceux qui s'y maintiennent semblent avoir des difficultés à se nourrir. Autour de 1800 av. J.-C., la plupart des cités ont été abandonnées. L'âge d’or du commerce interiranien, marqué par la présence de nombreux « trésors » et riches métropoles (coupe sur pied et bol tronconique), semble prendre fin vers 1800 av. J.-C. à 1700 av. J.-C., au moment même où les textes mésopotamiens cessent de parler du commerce oriental. Les grandes agglomérations du Turkménistan oriental (Altyn-depe et Namazga-depe) sont abandonnées et les grandes métropoles de la vallée de l’Indus disparaissent. Dans l'aire correspondant à la civilisation de l'Indus, le processus de régionalisation s’accentue avec la disparition des éléments les plus caractéristiques de l’unité harappéenne : l’écriture, les sceaux ou les poids. De nombreux éléments survivent pourtant au long du IIe millénaire av. J.-C. dans les régions orientales et méridionales de la zone.
					</p>
					<p>
						Vers 1900 av. J.-C., des signes montrent que des problèmes apparaissent. Les gens commencent à quitter les cités. Ceux qui s'y maintiennent semblent avoir des difficultés à se nourrir. Autour de 1800 av. J.-C., la plupart des cités ont été abandonnées. L'âge d’or du commerce interiranien, marqué par la présence de nombreux « trésors » et riches métropoles (coupe sur pied et bol tronconique), semble prendre fin vers 1800 av. J.-C. à 1700 av. J.-C., au moment même où les textes mésopotamiens cessent de parler du commerce oriental. Les grandes agglomérations du Turkménistan oriental (Altyn-depe et Namazga-depe) sont abandonnées et les grandes métropoles de la vallée de l’Indus disparaissent. Dans l'aire correspondant à la civilisation de l'Indus, le processus de régionalisation s’accentue avec la disparition des éléments les plus caractéristiques de l’unité harappéenne : l’écriture, les sceaux ou les poids. De nombreux éléments survivent pourtant au long du IIe millénaire av. J.-C. dans les régions orientales et méridionales de la zone.
					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class="societe col-lg-12">
					<h2 > <u>Causes de l'effondrement</u></h2>
					<p>
						Une des causes de cet effondrement peut avoir été un changement climatique majeur. Au XXVIe siècle av. J.-C., la vallée de l'Indus était verdoyante, sylvestre et grouillante de vie sauvage, beaucoup plus humide aussi. Les crues étaient un problème récurrent et semblent, à plus d'une occasion, avoir submergé certains sites. Les habitants de l'Indus complétaient certainement leur régime alimentaire en chassant, ce qui semble presque inconcevable aujourd'hui quand on considère l'environnement desséché et dénudé de la zone. Autour de 1800 av. J.-C., le climat s'est modifié, devenant notablement plus frais et plus sec. Mais cela ne suffit pas pour expliquer l'effondrement de la civilisation de l'Indus.
					</p>
					<img src="images/indus1.jpg" alt="indus" class="indus1 img-fluid float-left">
					<p>
						Le facteur majeur pourrait être la disparition de portions importantes du réseau hydrographique Ghaggar-Hakra, identifié par certaines théories au fleuve Sarasvatî. Une catastrophe tectonique pourrait avoir détourné les eaux de ce système en direction du réseau gangétique. En fait, ce fleuve, jusqu'alors mythique, fait irruption dans la réalité lorsqu'à la fin du XXe siècle, les images satellitaires permettent d'en reconstituer le cours dans la vallée de l'Indus2. De plus, la région est connue pour son activité tectonique et des indices laissent à penser que des événements sismiques majeurs ont accompagné l'effondrement de cette civilisation. Évidemment, si cette hypothèse était confirmée et que le réseau hydrographique de la Sarasvatî s'est trouvé asséché au moment où la civilisation de l'Indus était à son apogée, les effets ont dû être dévastateurs. Des mouvements de population importants ont dû avoir lieu et la « masse critique » indispensable au maintien de cette civilisation a pu disparaître dans un temps assez court, causant son effondrement.
						Une autre cause possible de l'effondrement de cette civilisation peut avoir été l'irruption de peuples guerriers Aryens au Nord-Ouest de l'actuelle Inde et qui auraient provoqué la rupture des relations commerciales avec les autres pays (les actuels Ouzbékistan et Turkménistan méridionaux, la Perse, la Mésopotamie). Or le commerce est l'une des raisons d'être des villes : elles se développent surtout autour des ports ou des nœuds routiers. Ces peuples plus armés que le proche et Moyen-Orient comme le montre l'archéologie3 se trouvaient en Bactriane aux alentours de l'an 2000 av. J.-C. Ce sont eux qui, selon certaines hypothèses qui ne font pas consensus malgré le faisceau d'indices, auraient apporté le sanskrit en Inde. Ils auraient donc indirectement provoqué la désorganisation des cités de l'Indus avant de s'installer en Inde vers 1700 av. J.-C.4,5 apportant probablement avec eux les védas6.
					</p>
					<p>
						Au XIXe siècle, les ingénieurs britanniques découvrent des ruines qui ne stimulent pas leur curiosité mais qui sont des sources abondantes de briques, un matériau commode pour la construction des chemins de fer. Leur exploitation a détruit un certain nombre de sites archéologiques.
					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container container_2">
			<div class="row">
				<div class="peuble col-lg-12">
					<h2> <u>Architecture et urbanisme</u></h2>
					<p class="text-justify">
						La tendance à la planification urbaine de la civilisation de l'Indus est évidente dans les grandes colonies et les cités. De façon typique, la ville est partagée en deux zones : une première comportant une plate-forme de terre surélevée que les premiers archéologues nommeront la citadelle et une seconde, appelée cité basse, composée de maisons et de magasins étroitement entremêlés, séparés par un réseau de rues et d'allées, bien définies, suivant un plan précis, de largeurs fixées et en usage dans la quasi-totalité des sites.
						Les bâtiments principaux étaient construits en briques, cuites ou crues, d'une forme rigoureusement standardisée. Un système décimal de poids et mesures était utilisé dans toute l'aire. Les villes les plus peuplées comptaient jusqu'à 30 000 habitants.
						À Harappa, Mohenjo-daro et sur le site récemment découvert de Rakhigarhi, les plus connues et probablement les plus peuplées des villes de cette civilisation, la planification urbaine incluait le premier système au monde de traitement des eaux usées. À l'intérieur des villes, l'eau était tirée de puits. Dans les maisons, une pièce était destinée aux ablutions, les eaux usées étaient dirigées vers des égouts couverts qui longeaient les rues principales. Les maisons ouvraient seulement vers des cours intérieures ou sur des ruelles, se tenant ainsi éloignées des éventuelles mauvaises odeurs.

					</p>
					
					<p class="text-justify">
						Le rôle de la citadelle est encore sujet à débat. Contrairement aux civilisations contemporaines de la Mésopotamie et de l'Égypte, aucune structure de grande taille n'était ici construite, aucune ne semble avoir été un temple ou un palais donc pas de trace matérielle prouvant l'existence de roi, d'armées ou de prêtres. Il convient toutefois de s'interroger sur le rôle symbolique des citadelles.
					</p>
					<img src="images/indus6.jpg" alt="images indus" class="indus6 img-fluid float-right">
					<p class="text-justify">
						Certaines structures sont cependant identifiées comme des greniers qui signifierait l’existence de surplus agricoles, une raison de cette floraison urbaine..
					</p>
					<p class="text-justify">
						À Mohenjo-Daro, la cité la mieux conservée, on a découvert dans la citadelle le « grand bain », une piscine rectangulaire entourée de galeries qui pourrait avoir été un bain public. Deux escaliers symétriques donnent accès à un bassin dont l’étanchéité est assurée par des joints de bitume entre les briques. Bien que la citadelle ait été entourée de murs, il ne semble pas qu'elle ait eu un rôle défensif mais plutôt de protection contre les crues. La ville basse est formée de rues régulières orientées nord-sud et est-ouest. Les maisons sont d’une superficie de 50 à 120 m2. Elles possèdent un étage auquel on accède par un escalier intérieur. Certaines sont dotées d’un puits privé, les autres sont approvisionnées en eau par des puits publics. Les maisons sont équipées de salles de bain dont les eaux usées sont évacuées par une rigole en plan incliné qui conduit au caniveau de la rue.
					</p>
					<p class="text-justify">
						Les différents quartiers de Mohenjo-Daro ont été reconstruits à plusieurs reprises suivant le même plan. À chaque fois, le système de canalisation et d’égout a été réaménagé, ce qui suppose l’existence d’une autorité publique. Pourtant, aucun des bâtiments de Mohenjo-Daro et de Harappa ne peut être considéré comme un temple ou un palais. Aucune trace n’indique avec certitude la prédominance d’une classe de rois ou de prêtres.
						La plupart des habitants des villes semblent avoir été des commerçants ou des artisans, vivant ensemble dans des zones bien définies déterminées suivant leur activité. Des matériaux, provenant de régions lointaines, étaient utilisés dans la confection de sceaux, de perles et d'autres objets. Les sceaux comportent des représentations animales, divines et des inscriptions. Quelques-uns d'entre eux étaient utilisés pour faire des sceaux dans l'argile mais ils avaient probablement d'autres emplois. La découverte de sceaux jusqu’en Mésopotamie atteste de l'existence d'un commerce lointain.
						Bien que certaines maisons soient plus grandes que d'autres, il ressort de l'observation de ces villes, une impression d'égalitarisme, de vaste société de classe moyenne, toutes les maisons ayant accès à l'eau et au traitement des eaux usées.

					</p>
				</div>
			</div>
		</div>

		<div class="container hr">
			<div class="row">
				<hr class="offset-lg-3 col-lg-6 offset-lg-3">
			</div>
		</div>

		<div class="container infos_supp">
			<div class="row">
				<div class="col-lg-7 col-12">
					<div id="tabs">
						<ul class="tabs_ul">
							<li><a href="#tabs-1" class='a'>Lectures</a></li>
							<li><a href="#tabs-2" class='a'>Films & Documentaires</a></li>
							<li><a href="#tabs-3" class='a'>Achats divers</a></li>
							<li><button type="button" class="btn btn_images" data-toggle="modal" data-target=".modal_indus">Images</button></li>	
						</ul>
						<div id="tabs-1">
							<p>
								<ul>
									<li>D.K. Chakrabarti, Indus Civilization Sites in India: New Discoveries, Marg Publications, Mumbai, 2004 (EN) </li>
									<li>S.P. Gupta, The Indus-Saraswati Civilization : Origins, Problems and Issues, 1996 (EN)</li>
									<li>J. Mark Kenoyer, Ancient cities of the Indus Valley Civilization., Oxford University Press, 1998 (EN)</li>
									<li>Upinder Singh, A History of Ancient and Early Medieval India : From the Stone Age to the 12th century, New Dehli et Upper Saddle River, Pearson Education, 2008 (EN)</li>
								</ul>
							</p>
						</div>
						<div id="tabs-2">
							<ul>
								<li><a href="https://www.youtube.com/watch?time_continue=1821&v=TkbuMDwVbO8" target="blank">The Indus Civilization</a></li>
								<li><a href="https://www.harappa.com/video/harappan-expertise-civil-engineering">Harappan Expertise in Civil Engineering</a></li>
								<li><a href="https://www.youtube.com/watch?v=N9LMOTa9vKc ">Civilisations disparues La vallée de l'Indus </a></li>
								<li><a href="https://www.youtube.com/watch?v=R6ARAgmFLRg ">INDE Histoire - Civilisation de l'Indus (jusqu'en 1700 av JC) </a></li>
							</ul>						
						</div>
						<div id="tabs-3">
							<p>
								En cliquant sur le lien ci-dessous, vous pourrez effectuer des achats (films, documentaires, livres).
							</p>
							<p>Pour les achats, c'est <a href="achat_indus.php" alt="page redirection" target="blank">ICI</a></p>
						</div>
					</div>

					<div class="modal fade modal_indus galerie_images" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
					  <div class="modal-dialog modal-lg">
					    <div class="modal-content">
					      <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
							  <div class="carousel-inner">
							    <div class="carousel-item active">
							      <img class="d-block w-100" src="images/indus2.jpg" alt="First slide">
							    </div>
							    <div class="carousel-item">
							      <img class="d-block w-100" src="images/harap.jpg" alt="Second slide">
							    </div>
							  </div>
							  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
							    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
							    <span class="sr-only">Previous</span>
							  </a>
							  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
							    <span class="carousel-control-next-icon" aria-hidden="true"></span>
							    <span class="sr-only">Next</span>
							  </a>
							</div>
					    </div>
					  </div>
					</div>


					
				</div>
				<div class="infos col-lg-5 col-12">
					<h2> A savoir : </h2>
					<ul class="text-justify">
						<li>Redécouverte en 1920 fortuitement par un archéologue indien qui cherchait les vestiges d’un ancien temple bouddhiste, les mystères sont encore nombreux : nul ne connait son système de pouvoir, ni ses moyens de subsistance.</li>
						<li>Superficie de 2,5 millions de kilomètres carrés, il s'agissait à l'époque de la civilisation la plus étendue au monde : regroupant cinq millions de personnes (10% de la population mondiale de l'époque).
						</li>
						<li>Fait partie des toutes premières civilisation au même titre que la Mésopotamie et l’Égypte ancienne.
						</li>
						<li>Rarchitecture et urbanisme : répartition en deux zones : plate-forme de terre surélevée appelée citadelle et une seconde (cité basse), composée de maisons et magasins étroitement entremêlés, séparés par un réseau de rues et d'allées, bien définies, suivant un plan précis, de largeurs fixées et en usage dans la quasi-totalité des sites. Le rôle de la citadelle est encore sujet à débat. Contrairement aux civilisations contemporaines de la Mésopotamie et de l'Égypte, aucune structure de grande taille n'était construite, aucune ne semble avoir été un temple ou un palais donc pas de trace matérielle prouvant l'existence de roi, d'armées ou de prêtres. Il convient toutefois de s'interroger sur le rôle symbolique des citadelles.
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section>

	<div class="container hr">
		<div class="row">
			<hr class="offset-lg-3 col-lg-6 offset-lg-3">
		</div>
	</div>

	<section>
		<div class="container com">
			<div class="row">
				<?php include("commentaire.php"); ?> 
			</div>
		</div>
	</section>
	</main>

	<!--footer -->
	<?php include("footer.php"); ?> 
</body>
</html>                 
