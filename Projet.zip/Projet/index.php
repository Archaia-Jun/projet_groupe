<!DOCTYPE html>
<html>
<head>
  <title>Archaia - Mésoamérique – Amérique précolombienne</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/Mesoamerique_Amerique_precolombienne.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="stylesheet" type="text/css" href="css/commentaire.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <style type="text/css">
  	.index_carousel {
  		margin-top: 50px;
  	}

  	.card_index {
  		margin-top: 10%;
  		margin-bottom: 10%;
  	}

  	.card-header, .card-footer {
  		background-color: #892224 !important;
  		color: white; 
  	}

  	.btn-primary, .btn-primary:hover {
  		background-color: white !important;
  		color: #892224;
  	}
  </style>
  
</head>
<body>
	<!--header-->
	<?php include("header.php"); ?>

	<!-- MAIN -->
	<main>
	<section>
		<div id="carouselExampleIndicators" class="carousel slide index_carousel" data-ride="carousel">
		  <ol class="carousel-indicators">
		    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
		    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
		    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
		  </ol>
		  <div class="carousel-inner">
		    <div class="carousel-item active">
		      <img class="img-fluid d-block w-100" src="images/img5.jpg" alt="First slide">
		    </div>
		    <div class="carousel-item">
		      <img class="img-fluid d-block w-100" src="images/img7.jpg" alt="Second slide">
		    </div>
		  </div>
		  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
		    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
		    <span class="carousel-control-next-icon" aria-hidden="true"></span>
		    <span class="sr-only">Next</span>
		  </a>
		</div>
	</section>

	<section class="card_index">
	<div class="container">

      <h1 class="card_index my-4">Aires Culturelles</h1>

      <!-- Marketing Icons Section -->
      <div class="row">
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h4 class="card-header">Mésoamérique <br/> (Amérique moyenne) </h4>
            <div class="card-body">
              <p class="card-text">Caractéristiques de la première civilisation Mésoaméricaine : les Olmèques : Préclassique moyen -1200</les></p>
              <p>Super-aire culturelle de l'Amérique précolombienne.
              La préhistoire et l'histoire de cette aire sont traditionnellement divisées en trois grandes époques : préclassique, classique et postclassique.</p>
            </div>
            <div class="card-footer">
              <a href="Mesoamerique_Amerique_precolombienne.php" class="btn btn-primary" target="blank">Lire la suite</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h4 class="card-header">Mésopotamie <br/> (Bronze ancien)</h4>
            <div class="card-body">
              <p class="card-text">La plus ancienne civilisation connue à ce jour se situait en Mésopotamie (actuel Irak). Les Sumériens : Néolithique.</p>
              <p>Super-aire culturelle de l'Amérique précolombienne.
              L'histoire de la Mésopotamie s'étend sur plus de trois millénaires. Dant cette région s'est développée une importante civilisation à partir de la fin du IVe millénaire av. J.‑C. et durant le IIIe millénaire av. J.‑C.</p>
            </div>
            <div class="card-footer">
              <a href="Mesopotamie_Irak_actuel.php" class="btn btn-primary" target="blank">Lire la suite</a>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-4">
          <div class="card h-100">
            <h4 class="card-header">Vallée de l'Indus <br/> (Antiquité)</h4>
            <div class="card-body">
              <p class="card-text">La civilisation Harapéenne (vers 8000 av. J.-C. – 1900 av. J.-C.), dite aussi civilisation de la vallée de l'Indus, est une civilisation dont l'aire géographique s'étendait principalement dans la vallée du fleuve Indus dans le sous-continent indien (Pakistan actuel). <br/> La civilisation de l’Indus est très ancienne et méconnue. Son écriture (glyphes) reste à ce jour non déchiffrée.</p>
            </div>
            <div class="card-footer">
              <a href="Vallee_de_Iindus.php" class="btn btn-primary" target="blank">Lire la suite</a>
            </div>
          </div>
        </div>
      </div>
	</section>
	</main>

	<!--footer -->
	<?php include("footer.php"); ?> 
</body>
</html>                 
