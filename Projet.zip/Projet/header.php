<!-- NAVBAR -->
<!--<header> -->

<header>
 <nav class="nav navbar navbar-expand-lg navbar-light">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end nav_right" id="navbarNav">
      <ul class="navbar-nav justify-content-end">
        <li class="nav-item active">
          <a class="nav-link cv" href="#">Accueil</a>
        </li>
        <li class="nav-item">
          <a class="nav-link realisation" href="contenu.php">Civilisation</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="scroll" href="formulaire.php">Inscription</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="scroll" href="publication.php">Formulaire d'inscription</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="scroll" href="#">A propos</a>
        </li>
      </ul>
    </div>
  </nav>
</header>