<!DOCTYPE html>
<html>
<head>
  <title>Puzzle</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
  <style type="text/css">

  body {
    background-color: #fdeac9 !important;
  }

	#flags, #droparea {
  }
  
  #flags {

  }

	#flags div {
    width: 90px; 
    height: 112px;
  }

	#flags>div, #droparea>div {
	
  border: 1px solid black;
	text-align: center;
	}

  #flags {
   
  }
  
  #droparea {

  }

	#droparea div {
    width: 90px; 
    height: 112px;
  }

  #droparea p {
    display: none;
  }

  .container {
  }

  .a {
    margin-top: 100px;
  }

  .b {
    padding-left: 300px;
    padding-right: 300px;
    margin-bottom: 100px;
  }

	</style>
</head>
<body>

	<!--header-->
	<?php include("header.php"); ?>
	
	
	<div class="container-fluid a">
	  <div id="flags" class="row"></div>
	</div>


	<div class="container b">
	  <div id="droparea" class="row col-lg-12"></div>
	</div>

	<!--footer -->
	<?php include("footer.php"); ?> 

	

	<script type="text/javascript">
  		var flagsArr =
  		["img/aztec1.jpeg","img/aztec2.jpeg","img/aztec3.jpeg","img/aztec4.jpeg","img/aztec5.jpeg","img/aztec6.jpeg","img/aztec7.jpeg", "img/aztec8.jpeg", "img/aztec9.jpeg", "img/aztec10.jpeg", "img/aztec11.jpeg", "img/aztec12.jpeg", "img/aztec13.jpeg", "img/aztec14.jpeg", "img/aztec15.jpeg"];
  		var namesArr =
  		["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"]


  		$(document).ready(function(){
  			
        shuffle(flagsArr);
  			$.each(flagsArr, function(index,value){
  				var flag = value.slice (9,-5); //en fonction du nom du fichier , ex: images/uk.png i=1, /=7
  				$("<div><img src="+value+"></div>").appendTo("#flags").draggable({revert:true,scope:flag});
  			});

  			shuffle(namesArr);
  			$.each(namesArr, function(index,value){
  				$("<div>"+"<p>"+value+"</p>"+"</div>").appendTo("#droparea").droppable({scope:value.toLowerCase(),
  					drop:function(event, ui){
  						$(ui.draggable).append($(this).text());
  						$(this).accept("explode", "slow");
              ui.draggable.draggable( 'option', 'revert', false );
  					}});
  			});
  		});

  		function shuffle()
  		{
  			return flagsArr.sort(function(){
  				return .5 - Math.random(); //n'ira pas jusqu'à 8 ou 9
  			});
  		}


  		console.log(shuffle);
  	</script>
</body>
</html>