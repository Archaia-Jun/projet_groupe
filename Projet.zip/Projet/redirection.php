<!DOCTYPE html>
<html>
<head>
  <title>Archaia - Achat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="stylesheet" type="text/css" href="css/redirection.css">
  <link rel="stylesheet" type="text/css" href="csscommentaire.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
</head>
<body>

	<!--header-->
	<?php include("header.php"); ?>

	<main>
		<section>
			<div class="container ">
				<div class="row">
					<div class="header_jum col-lg-12">
						<div class="jumbotron_achat jumbotron">
						    <h1 class="display-4">Achat</h1>
						    <p class="lead">This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section>
			<div class="container">
				<div class="row">
					<div class="accordion col-12" id="accordion">
					  <div class="card">
					    <div class="card-header" id="headingOne">
					      <h5 class="mb-0">
					        <button class="btn btn-link btn_achat" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
					          Collapsible Group Item #1
					        </button>
					      </h5>
					    </div>
					    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
					      <div class="card-body">
					        <div class="row achat_deck">
					        	<div class="col-12 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-12 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-12 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<p><a href="#">En cliquant sur ce lien vous aurez plus de choix</a></p>
						      </div>
						    </div>
						</div>


					  <div class="card">
					    <div class="card-header" id="headingTwo">
					      <h5 class="mb-0">
					        <button class="btn btn-link collapsed btn_achat" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
					          Collapsible Group Item #2
					        </button>
					      </h5>
					    </div>
					    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
					      <div class="card-body">
					      	<div class="row achat_deck">
					        	<div class="col-4 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-4 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-4 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<p><a href="#">En cliquant sur ce lien vous aurez plus de choix</a></p>
						      </div>
						    </div>
						</div>



					  <div class="card">
					    <div class="card-header" id="headingTwo">
					      <h5 class="mb-0">
					        <button class="btn btn-link collapsed btn_achat" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
					          Collapsible Group Item #3
					        </button>
					      </h5>
					    </div>
					    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
					      <div class="card-body">
					      	<div class="row achat_deck">
					        	<div class="col-4 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-4 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<div class="col-4 col-sm-4">
									<div class="card border-success mb-3" style="max-width: 18rem;">
										<div class="card-header bg-transparent border-success">Titre</div>
										<div class="card-body text-success">
											<img src="images/olmeques.jpg" alt='olmeques' class="img-fluid">
										</div>
										<div class="card-footer bg-transparent border-success">49 euros</div>
									</div>
								</div>
								<p><a href="#">En cliquant sur ce lien vous aurez plus de choix</a></p>
						      </div>
						    </div>
						</div>
					  </div>
					</div>
				</div>
			</div>
		</section>
	</main>

	<!--footer -->
	<?php include("footer.php"); ?> 
</body>
</html>