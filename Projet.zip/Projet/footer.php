<!-- Footer -->
<footer class="">
	<div class="container">
	  	<div class="reseaux text-center">
	   		<a href="#"><img class="img-fluid" src="images/facebook.png" ></a>
	   		<a href="#"><img class="img-fluid" src="images/twitter.png" ></a>
	   		<a href="#"><img class="img-fluid" src="images/flickr.png" ></a>
	   		<a href="#"><img class="img-fluid" src="images/rss.png" ></a>
	   	</div>
	   	<p class="copy m-0 text-center text-white">Copyright &copy; Archaia 2018</p>
 	</div>
<!-- /.container -->
</footer>
