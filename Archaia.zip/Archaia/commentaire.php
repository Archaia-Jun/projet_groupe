<div class="col-lg-6">
	<form action="commentaires/post_commentaire.php" method="post"> 
		<h1>
			<label class="h1_com" for="commentaire">Poster un commentaire</label>
		</h1>
	   	<textarea class="col-lg-12 textarea_com" rows="5" name="commentaire" id="commentaire" placeholder="Laissez votre message ..."></textarea>
		<button type="submit" class="btn btn_com">Envoyer</button> 	
	</form>
</div>

