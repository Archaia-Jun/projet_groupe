<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Formulaire</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
		<link rel="stylesheet" type="text/css" href="css/myStyle.css"/>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
	</head>
	<body>
		<div id="formulaire_login">
			<form action="connect.php" method="post">
			    <fieldset>
		        	<legend>Se connecter</legend> 
					<p>
						<label for="identifiant">Identifiant</label>
			        	<input type="text" name="identifiant_login" id="identifiant_login"/>
			    	</p>
					<p>
						<label for="password">Mot de passe</label>
			        	<input type="password" name="password_login" id="password_login"/>
			        </p>
			    </fieldset>
			    <p>Vous ne vous êtes pas encore inscrit! <a href="inscription.php">Cliquez ici</a></p>
			    <p><button type="submit" id="submit_login">Valider</button></p>
			</form>
		<!-- Nous allons afficher un retour en jQuery au visiteur -->
		</div>
		<div id="connect_login">
		</div>
		<script>
		var user = document.getElementById('identifiant_login').value;
		$(document).ready(function(){
	    	$("#submit_login").click(function(e){
	       	 	e.preventDefault();
	       		$.post(
	            	'connect.php', // Un script PHP que l'on va créer juste après
	            	{
	                	identifiant : $("#identifiant_login").val(),  // Nous récupérons la valeur de nos input que l'on fait passer à connect.php
	               	 	password : $("#password_login").val()
	            	},
	            	function(data){
	                	if(data == 'Success'){
	                    	 // Le membre est connecté. Ajoutons lui un message dans la page HTML.
	                     	$("#formulaire_login").fadeOut();
	                     	$("#connect_login").html("<p>" + user + "</p>");
	                	}
	                	else{
	                    	 // Le membre n'a pas été connecté. (data vaut ici "failed")
	                    	$("#connect_login").html("<p>Erreur lors de la connexion...</p>");
	                	}
	            	},
	        	);
	    	});
		});
		</script>
	</body>
</html>