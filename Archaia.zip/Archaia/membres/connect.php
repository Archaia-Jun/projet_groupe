<?php
    $identifiant = $_POST['identifiant_login'];
    $password = $_POST['password_login'];
 
    if(($_POST['identifiant_login']) && ($_POST['password_login'])){
            $_SESSION['identifiant_login'] = $identifiant;
            echo "Success";    
        }
        else{ // Sinon
            echo "Failed";
        }
?>