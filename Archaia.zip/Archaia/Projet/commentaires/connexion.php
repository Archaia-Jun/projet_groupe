<?php
try {
    $strConnection = 'mysql:host=localhost; dbname=archaia_project';
    $pdo=new PDO($strConnection, 'root', 'root');
} catch (PDOException $e) {
    $msg = 'ERREUR DE CONNECTION' .$e->getMessage();
    die($msg);
}
?>