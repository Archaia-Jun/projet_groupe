<?php 
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Formulaire d'ajout</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  
  <link rel="stylesheet" type="text/css" href="css/publication.css">
  <link rel="stylesheet" type="text/css" href="css/header.css">
  <link rel="stylesheet" type="text/css" href="css/commentaire.css">
  <link rel="stylesheet" type="text/css" href="css/footer.css">
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
  
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
    <!--HEADER-->
    <?php include("header.php"); ?>

    <main>
        <section>
            <div class="container">
                <div class="row">
                  <div class="publi_titre">
                    <h1 class="col-lg-12">Vous souhaitez participer et enrichir la base de données, apporter une information complémentaire ?</h1>
                    <p class="col-lg-8 col-lg-offset-4">C'est très simple, prenez quelques instants pour partager vos conaissances :</p>
                  </div>
                  <div class="publi_form col-lg-12">
                    <h2>Formulaire</h2>
                    <form method="post" action="articles/valid_publication.php">
                      <div class="form_publi input_row form-group row">
                        <label for="formGroupExampleInput" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Nom</label>
                          <input type="text" class="form-control col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="formGroupExampleInput" placeholder="Nom" required>
                      </div>
                      <div class="input_row form-group row">
                        <label for="formGroupExampleInput2" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Prénom*</label>
                        <input type="text" class="form-control col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="formGroupExampleInput2" placeholder="Prénom" required>
                      </div>
                      <div class="input_row form-group row">
                        <label for="formGroupExampleInput3" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Email*</label>
                        <input type="mail" class="form-control  col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="formGroupExampleInput2" placeholder="Email" required>
                      </div>
                      <div class="input_row form-group row">
                        <label class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label" for="inlineFormCustomSelect">Que proposez-vous </label>
                        <select class="custom-select col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="inlineFormCustomSelect">
                          <option selected>Choix</option>
                          <option value="1">Complément d'information</option>
                          <option value="2">Nouvelle civilisation</option>
                          <option value="3">Sujets connexes</option>
                          <option value="4">Autres ...</option>
                        </select>
                      </div>
                      <div class="input_row form-group row">
                        <label for="formGroupExampleInput4" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Nom de la civilisation*</label>
                        <input type="text" class="form-control col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="formGroupExampleInput2" placeholder="Nom de la civilisation" required>
                      </div>
                      <div class="input_row form-group row">
                        <label for="formGroupExampleInput5" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Periode</label>
                        <input type="text" class="form-control col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="formGroupExampleInput2" placeholder="Periode" required>
                      </div>
                       <div class="input_row form-group row">
                        <label for="comment" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Informations sur la civilisation*</label>
                        <textarea class="form-control col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" rows="5" id="comment" required=""></textarea>
                      </div> 
                      <div class="input_row form-group row">
                        <label for="formGroupExampleInput2" class="col-12 col-sm-4 col-md-3 col-lg-2">Images/Photos</label>
                        <input type="file" id="file" class="form-control-file col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="formGroupExampleInput2" placeholder="Images/Photos" required>
                      </div>
                      <p class="para_publi">Si vous pensez maîtriser le sujet, vous pouvez vous même rédiger l'article:</p>
                      <div class="input_row form-group row">
                        <label for="titre" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Titre de l'article</label>
                        <input type="text" class="form-control-file col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" id="titre" name="titre" placeholder="Titre de l'article" required>
                      </div>
                      <div class="form-group row">
                        <label for="donnees" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Fiche informative</label>
                        <textarea class="form-control-file col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" rows="5" name="donnees" id="donnees" required></textarea>
                      </div> 
                      <div class="form-group row">
                        <label for="texte" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Rédaction de l'article</label>
                        <textarea class="form-control-file col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" rows="5" name="texte" id="texte" required></textarea>
                      </div> 
                      <div class="form-group row">
                        <label for="infos" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Informations complémentaires</label>
                        <textarea class="form-control-file col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" rows="5" name="infos" id="infos" required></textarea>
                      </div> 
                      <div class="input_row form-group row">
                        <label for="sources" class="col-12 col-sm-4 col-md-3 col-lg-2 col-form-label">Sources externes</label>
                        <input type="text" class="form-control-file col-12 col-sm-8 col-sm-offset-4 col-lg-4 col-lg-offset-8" name="sources" id="sources" placeholder="Sources externes" required>
                      </div>
                        <button type="submit" class="btn btn_publi">Envoyer</button>
                    </form>
                  </div>
                </div>
            </div>
        </section>
    </main>

    <!-- FOOTER -->
    <?php include("footer.php"); ?> 
</body>
</html>