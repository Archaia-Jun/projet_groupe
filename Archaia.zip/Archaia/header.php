<!-- NAVBAR -->
<!--<header> -->

<header>
 <nav class="nav navbar fixed-top navbar-expand-lg navbar-light col-lg-12">
  <a class="navbar-brand text-white" href="index.php">Archaia</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end nav_right" id="navbarNav">
      <ul class="navbar-nav justify-content-end">
        <li class="nav-item active">
          <a class="nav-link cv text-white" href="index.php">Accueil</a>
        </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Civilisation
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="Mesoamerique_Amerique_precolombienne.php">Mésoamérique – Amérique précolombienne</a>
          <a class="dropdown-item" href="Mesopotamie_Irak_actuel.php">Mésopotamie – Irak actuel</a>
          <a class="dropdown-item" href="Vallee_de_Iindus.php">Vallée de l’Indus</a>
        </div>
      </li>
        <li class="nav-item">
          <a class="nav-link text-white" id="scroll" href="publication.php">Base de données</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" id="scroll" href="formulaire.php">Inscription</a>
        </li>
      </ul>
      <ul class="navbar-nav mr-right">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-white"  href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            Connexion
            </a>
            <div id="connect_login">
              <div class="dropdown-menu p-3 connexion" id="formulaire_login">
                  <form class="form-horizontal" method="post" action="membres/connect.php" accept-charset="UTF-8">
                      <input class="form-control login" type="text" name="identifiant_login" id="identifiant_login" placeholder="Identifiant">
                      <input class="form-control login" type="password" name="password_login" id="password_login" placeholder="Mot de passe">
                      <button class="btn btn_connexion" type="submit" name="submit_login" id="submit_login" value="Login">Connexion</button>
                  </form>
              </div>
            </div>
            
            <script>
                var user = document.getElementById('identifiant_login').value;
                $(document).ready(function(){
                    $("#submit_login").click(function(e){
                        e.preventDefault();
                        $.post(
                            'membres/connect.php', // Un script PHP que l'on va créer juste après
                            {
                                identifiant : $("#identifiant_login").val(),  // Nous récupérons la valeur de nos input que l'on fait passer à connect.php
                                password : $("#password_login").val()
                            },
                            function(data){
                                if(data == 'Success'){
                                     // Le membre est connecté. Ajoutons lui un message dans la page HTML.
                                    $("#connect_login").html("<p>Connecté</p>");
                                }
                                else{
                                     // Le membre n'a pas été connecté. (data vaut ici "failed")
                                    $("#connect_login").html("<p>Erreur lors de la connexion...</p>");
                                }
                            },
                        );
                    });
                });
            </script>
        </li>
        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Jeux
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="puzzle.php">Puzzle</a>
          <a class="dropdown-item" href="quiz.php">Quiz</a>
        </div>
        <li class="nav-item">
          <a class="nav-link text-white" href="A_propos.php">A propos</a>
        </li>
      </ul>
    </div>
  </nav>
</header>