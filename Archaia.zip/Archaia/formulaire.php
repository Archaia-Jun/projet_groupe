<!DOCTYPE html>
<html>

	<head>
		<title>Formulaire d'inscription</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


		<link rel="stylesheet" type="text/css" href="css/header.css">
		<link rel="stylesheet" type="text/css" href="css/footer.css">
		<link rel="stylesheet" type="text/css" href="css/formulaire.css">

		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/all.css" integrity="sha384-+d0P83n9kaQMCwj8F4RJB66tzIwOKmrdb46+porD/OvrJ+37WqIM7UoBtwHO6Nlg" crossorigin="anonymous">

		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>

		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<link rel="stylesheet" href="/resources/demos/style.css">
		<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	</head>

	<body>
		
		<!--header-->
		<?php include("header.php"); ?>

		<main>
        <section>
            <div class="container">
                <div class="row">
                	<div class="row">
	                  <div class="form_titre">
	                    <h1 class="col-lg-12">Bienvenue sur la page D'inscription</h1>
	                    <p class="col-lg-6 col-lg-offset-6">Veuillez remplir le formulaire d'inscription et si vous le souhaitez, vous pouvez aussi remplir un second formulaire. Ce second formulaire nous permettra d'en savoir davantages sur ce que vous rechercher sur Archaia.</p>
	                  </div>
                	<div class="form_one offset-lg-3 col-lg-6 offset-lg-3">
						<h2 class="col-lg-12">Inscription</h2>
	   					<div class="form_insc col-lg-12 text-bold">
		                    <form action="membres/confirm_inscription.php" method="post">
		                   		<div class="input_row form_publi form-group row">
		                        <label class="col-lg-4 col-form-label" for="civilite">Civilité</label>
		                        <select class="custom-select col-lg-7 col-lg-offset-5" name="civilite" id="civilite">
		                          <option selected>Choix</option>
		                          <option value="1">M.</option>
		                          <option value="2">Mme</option>
		                        </select>
		                      </div>
		                      <div class="input_row form-group row">
		                        <label for="identifiant" class="col-lg-4 col-form-label">Identifiant</label>
		                          <input type="text" class="form-control col-lg-7 col-lg_offset-5" name="identifiant" id="identifiant" placeholder="Identifiant" required>
		                      </div>
		                      
		                      <div class="input_row form-group row">
		                        <label for="nom" class="col-lg-4 col-form-label">Nom</label>
		                        <input type="text" class="form-control col-lg-7 col-lg-offset-5" name="nom" id="nom" placeholder="Nom" required>
		                      </div>
		                      <div class="input_row form-group row">
		                        <label for="prenom" class="col-sm-4 col-form-label">Prénom</label>
		                        <input type="text" class="form-control col-lg-7 col-lg-offset-5" name="prenom" id="prenom" placeholder="Prénom" required>
		                      </div>
		                      <div class="input_row form-group row">
		                        <label for="age" class="col-sm-4 col-form-label">Age</label>
		                        <input type="number" class="form-control col-lg-7 col-lg-offset-5" id="age" name="age" placeholder="Age" required>
		                      </div>
		                      <div class="input_row form-group row">
		                        <label for="pays" class="col-sm-4 col-form-label">Pays</label>
		                        <input type="text" class="form-control col-lg-7 col-lg-offset-5" id="pays" name="pays" placeholder="Pays" required>
		                      </div>
		                      <div class="input_row form-group row">
		                        <label for="mail" class="col-sm-4 col-form-label">Email</label>
		                        <input type="mail" class="form-control col-lg-7 col-lg-offset-5" id="mail" name="mail" placeholder="Email" required>
		                      </div>
		                      <div class="input_row form-group row">
		                        <label for="password" class="col-sm-4 col-form-label">Mot de passe</label>
		                        <input type="password" class="form-control col-lg-7 col-lg-offset-5" name="password" id="password" placeholder="Mot de passe" required>
		                      </div>
		                      <div class="input_row form-group row">
		                        <label for="password" class="col-sm-4 col-form-label">Confirmation du mot de passe</label>
		                        <input type="password" class="form-control col-lg-7 col-lg-offset-5" name="password" placeholder="Confirmez votre mot de passe" required>
		                      </div>
		                       <div class="form-group row">
		                        <label for="image" class="col-sm-4">Image/Photo de profil</label>
		                        <input type="file" class="form-control-file col-lg-7 col-lg-offset-5"  id="image" name="image" placeholder="Image ou photo" required>
		                      </div>
		                      <button type="submit" class="btn btn_publi" id="btn_form_1">Envoyer</button>
		                    </form>
						</div>
					</div>
            	</div>
            </div>
        </section>

       	<section>
            <div class="container">
                <div class="row">
                	<div class="form_two offset-lg-3 col-lg-6 offset-lg-3">
						<h2 class="col-lg-12">Qu'est-ce qui vous motive à consulter Archaia ?</h2>
	   					<div class="form_insc col-lg-12 text-bold">
		                    <form method="post">
		                   		<div class="input_row form-group row">
		                        <label class="col-12 col-sm-12 col-md-12 col-lg-4 col-form-label" for="inlineFormCustomSelect">Que souhaitez vous apporter au site ?</label>
		                        <select multiple class="form-control col-lg-7 col-lg-offset-5" id="inlineFormCustomSelect">
		                          <option value="1">Apporter mes connaissances dans la civilisation</option>
		                          <option value="2">Partager mes experiences, des voyages</option>
		                          <option value="2">Découvrir la civilisation</option>
		                          <option>Autres ...</option>
		                        </select>
		                      </div>                
		                      <div class="input_row form-group row">
		                        <label for="formGroupExampleInput2" class="col-12 col-sm-12 col-md-12 col-lg-4 col-form-label">D'autres choses à ajouter ?</label>
		                        <input type="text" class="form-control col-lg-7 col-lg-offset-5" id="formGroupExampleInput2" placeholder="" required>
		                      </div>
		                       <div class="input_row form-group row">
		                        <label for="comment" class="col-12 col-sm-12 col-md-12 col-lg-4 col-form-label">D'autres choses à ajouter ?</label>
		                        <textarea class="form-control col-lg-7 col-lg-offset-5" rows="5" id="comment" required=""></textarea>
		                      </div>
		                      <button type="submit" class="btn btn_publi" id="btn_form_2">Envoyer</button>
		                    </form>
						</div>
					</div>
            	</div>
            </div>
        </section>
    </main>


		<!--footer -->
		<?php include("footer.php"); ?> 
	</body>
</html>
